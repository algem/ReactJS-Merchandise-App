var express = require('express');
var router = express.Router();
var sql = require("mssql");
var conn = require("../connection/connect")();
var cors = require('cors');
var routes = function () {
    router.route('/')
    .get(function (req, res) {
        conn.connect().then(function () {
            var sqlQuery = "";
            sqlQuery = "SELECT [id],[Name],[UnitMeasurement],[PhotoFileName]"
            sqlQuery = sqlQuery + ",[UnitPrice],[Priority],[Completed],[order] "
            sqlQuery= sqlQuery + " FROM [ProductDB].[dbo].[Items]"         
            var req = new sql.Request(conn);
            req.query(sqlQuery).then(function (recordset) {
                res.json(recordset.recordset);
                conn.close();
            })
                .catch(function (err) {
                    conn.close();
                    res.status(400).send(JSON.stringify(err));
                });
        })
            .catch(function (err) {
                conn.close();
                res.status(400).send(JSON.stringify(err) );
            });
    });

    router.route('/')
    .get(function (req, res) {
        var _param = req.params.ItemName;
        conn.connect().then(function () {
            var sqlQuery = "";
            sqlQuery = "SELECT [id],[Name],[UnitMeasurement],[PhotoFileName]"
            sqlQuery = sqlQuery + ",[UnitPrice],[Priority],[Completed],[order] "
            sqlQuery= sqlQuery + " FROM [ProductDB].[dbo].[Items]"
            sqlQuery = sqlQuery + " WHERE Name = " + _param;

            var req = new sql.Request(conn);
            req.query(sqlQuery).then(function (recordset) {
                res.json(recordset.recordset);
                conn.close();
            })
                .catch(function (err) {
                    conn.close();
                    res.status(404).send(JSON.stringify(err));
                });
        })
            .catch(function (err) {
                conn.close();
                res.status(404).send(JSON.stringify(err) );
            });
    });

    /*
    router.route('/')
    .get(function (req, res) {
        var _emailAddress = req.params.EmailAddress;
        conn.connect().then(function () {
            var sqlQuery = "";
            sqlQuery = "SELECT [UserId],[FirstName],[LastName],[EmailAddress] ,[UserName]"
            sqlQuery = sqlQuery + " FROM [UserDB].[dbo].[Users]";
            sqlQuery = sqlQuery + " WHERE EmailAddress = " + _emailAddress;
            var req = new sql.Request(conn);
            req.query(sqlQuery).then(function (recordset) {
                res.json(recordset.recordset);
                conn.close();
            })
                .catch(function (err) {
                    conn.close();
                    res.status(404).send(JSON.stringify(err));
                });
        })
            .catch(function (err) {
                conn.close();
                res.status(404).send(JSON.stringify(err) );
            });
    });
    */
    router.route('/')
    .post(function (req, res) {
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Name", sql.VarChar(50), req.body.Name);
                request.input("UnitMeasurement", sql.VarChar(50), req.body.UnitMeasurement);
                request.input("PhotoFileName", sql.VarChar(50), req.body.PhotoFileName);                          
                request.input("UnitPrice", sql.VarChar(50), req.body.UnitPrice);
                request.input("Priority", sql.VarChar(50), req.body.Priority);
                
                 request.execute("Usp_InsertItem").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).send(req.body);
                    }).catch(function (err) {
                        conn.close();
                        res.status(400).send(JSON.stringify(err));
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send(JSON.stringify(err));
                });
            }).catch(function (err) {
                conn.close();
                res.status(400).send(JSON.stringify(err));
            });
        }).catch(function (err) {
            conn.close();
            res.status(409).send(JSON.stringify(err));
        });
    });

    router.route('/:id')
    .put(function (req, res) {
        var _userId = req.params.id;
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Name", sql.VarChar(50), req.body.Name);
                request.input("UnitMeasurement", sql.VarChar(50), req.body.UnitMeasurement);
                request.input("PhotoFileName", sql.VarChar(50), req.body.PhotoFileName);                          
                request.input("UnitPrice", sql.VarChar(50), req.body.UnitPrice);
                request.input("Priority", sql.VarChar(50), req.body.Priority);
                request.execute("Usp_UpdateItem").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).send(req.body);
                    }).catch(function (err) {
                        conn.close();
                        res.status(404).send(JSON.stringify(err));
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send(JSON.stringify(err));
                });
            }).catch(function (err) {
                conn.close();
                res.status(409).send(JSON.stringify(err));
            });
        }).catch(function (err) {
            conn.close();
            res.status(400).send(JSON.stringify(err));
        });
    });

    router.route('/:id')
    .delete(function (req, res) {
        var _itemId = req.params.id;
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Id", sql.Int, _itemId);
                request.execute("Usp_DeleteUser").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).json("UserId:" + _userId);
                    }).catch(function (err) {
                        conn.close();
                        res.status(400).send(JSON.stringify(err));
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send(JSON.stringify(err));
                });
            }).catch(function (err) {
                conn.close();
                res.status(400).send(JSON.stringify(err));
            });
        });
    });

return router;
};
module.exports = routes;