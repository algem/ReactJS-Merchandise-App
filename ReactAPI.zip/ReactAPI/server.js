
var express = require('express');
var cors = require('cors');
var app = express();

app.use(cors());


var port = process.env.port || 50976;

var bodyParser = require('body-parser');
const { Router } = require('express');

// create application/x-www-form-urlencoded parser
app.use(bodyParser.urlencoded({ extended: true }));

// create application/json parser
app.use(bodyParser.json());

var itemsController = require('./controller/itemsController')();
app.use("/api/GetAllRecords", itemsController);

app.listen(port, function () {
    var datetime = new Date();
    var message = "Server runnning on Port:- " + port + "\nStarted at :- " + datetime;
    console.log(message);
});

