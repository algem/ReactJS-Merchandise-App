export default class Merchandise {
   
  Id:number;
  ItemName: string;
  UnitMeasurement: string;
  Priority: string;
  PhotoFileName: string;
  UnitPrice: number;
  Completed: boolean;
  order: number;
  dateOrdered: string;

  
    constructor(item: any) {
      this.Id = item.Id
      this.UnitMeasurement= item.UnitMeasurement;
      this.ItemName = item.Name;
      this.Priority = item.Priority;
      this.PhotoFileName = item.PhotoFileName;
      this.UnitPrice = item.UnitPrice;  
      this.Completed = item.Completed;
      this.order = item.order; 
      this.dateOrdered = Date.now().toString();  
    }
  }
  

 