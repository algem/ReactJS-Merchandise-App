import React, { Component } from 'react';
import Counter from './counter'
class Counters extends Component {
   
    render() { 
       const {counters,onDelete,onEdit} = this.props
        return (
            <div>            
                {counters.map(counter => (
                    <Counter                     
                        key={counter.id} 
                        counter={counter}
                        onEdit={onEdit}
                        onDelete={onDelete} 
                    />                
                ))}           
            </div>
        );
    }
}
export default Counters ;