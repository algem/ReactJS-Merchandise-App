import React, { Component } from 'react';
import Counters from '../components/counters'
import '../App.css';
import axios from 'axios';
import Swal from 'sweetalert2';
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
require("react-bootstrap/ModalHeader");

const  apiUrl =  "http://localhost:50976/api/"
const PhotoUrl = "http://localhost:50976/Photos/";
class ListMerchandise extends Component{ 
  constructor(props) {
    super(props)
    console.log(this.props)
  }
    state = {
    counters: [], 
    thisRecord:[],  
    body:[],
    modal: false,
    name: "",
    counterId: "",
    ItemName:'' ,
    UnitMeasurement:'',
    UnitPrice: '',
    Priority: '',
    Completed:false,
    PhotoFileName: ''
  }
  
  componentDidMount() {
    axios.get(apiUrl + 'GetAllRecords')
      .then(res => {     
       this.setState({counters: res.data}); 
      })
  }
  handleDelete = (counterId)=>{
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it',
      }).then((result) => {
        if (result.isConfirmed) {       
          const urlPath = apiUrl + 'items/'
            axios.delete(urlPath, { params: { id: counterId } }).then(response => {
            console.log(response);
            const counters = this.state.counters.filter(c => c.id !== counterId);
            this.setState({counters});
          });
        } else if (result.isDismissed) {
          return;
        }
      })
  };


  handleEdit = (id)=>{
    this.counterId = id
    this.setState({ modal: true });
    this.thisRecord = this.state.counters.filter(c => c.id === id);
    
    this.setState({ItemName: this.thisRecord[0].ItemName});
    this.setState({UnitMeasurement: this.thisRecord[0].UnitMeasurement});
    this.setState({UnitPrice: this.thisRecord[0].UnitPrice});
    this.setState({Priority: this.thisRecord[0].Priority});
    this.setState({PhotoFileName: PhotoUrl + this.thisRecord[0].PhotoFileName});  
    this.setState({counters: this.thisRecord});    
  }

  handleCancell=()=>{
    this.setState({ modal: false });
    axios.get(apiUrl + 'GetAllRecords')
    .then(res => {     
     this.setState({counters: res.data}); 
    })
    this.props.history.push("/");  
  }

  handleSubmit=()=>{
    this.setState({ modal: false });   
    
    fetch(apiUrl + "UpdateRecord", {
      "method": "PUT",
      "headers": {
      "content-type": "application/json",
      "accept": "application/json"
      },
      "body": JSON.stringify({
          id: this.counterId,
          ItemName: this.state.ItemName,
          UnitMeasurement: this.state.UnitMeasurement,
          UnitPrice: this.state.UnitPrice,
          Priority: this.state.Priority,
          Completed: this.state.Completed,
          PhotoFileName: this.PhotoUrl + this.state.PhotoFileName
      })
    })
    .then(response => response.json())
    .then(response => {
        console.log(response)      
        this.props.history.push("/");
        axios.get(apiUrl + 'GetAllRecords')
        .then(res => {     
        this.setState({counters: res.data}); 
        });   
        Swal.fire(response.toString()); 
    })
    .catch(err => {
        console.log(err);
          Swal.fire({
        icon: 'error',
        title: 'Oops...',
          text: err.toString(),
        })  
        this.props.history.push("/");  
    });  
  }

  currencyFormat(num) {
    if (num === null) {
       num = 0.00; 
    }
    return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  }

  onImageChange = (e) => {       
    if (e.target.files && e.target.files[0]) {
      let reader = new FileReader();
      reader.onload = (e) => {
        this.setState({image: e.target.result});        
      };
      reader.readAsDataURL(e.target.files[0]);
      var fileName = e.target.files[0].name;
      this.setState({PhotoFileName: PhotoUrl + fileName});           
    }
  }

  render(){
    return(
      <React.Fragment>     
        <main className="container">   
          <Counters
          counters={this.state.counters}
          onDelete={this.handleDelete}
          onEdit={this.handleEdit}         
         />   
          <Modal show={this.state.modal} handleClose={e => this.modalClose(e)}>
          <h2 className="mr-2"> Edit</h2>
          <form onSubmit={this.onSubmit} >
              <div clasname="form-group">      
                  <label>Item Name</label>
                  <input type="text" 
                    className="form-control"
                      value={this.state.ItemName}
                      onChange={(e) => this.setState({ ItemName: e.target.value })}
                      id="ItemName"/>
              </div>
              <div clasname="form-group"> 
              
                  <label>Unit Measurement</label>
                  <input type="text" 
                    className="form-control"
                      value={this.state.UnitMeasurement}
                      onChange={(e) => this.setState({ UnitMeasurement: e.target.value })}
                      id="UnitMeasurement"/>
              </div>
              <div clasname="form-group">     
                  <label>Unit Price</label>
                  <input type="text" 
                    className="form-control"
                    value={this.state.UnitPrice}
                    onChange={(e) => this.setState({ UnitPrice: e.target.value })}
                    id="UnitPrice"/>
              </div>                                              
              <div clasname="form-group">                                        
                  <input type="file"                      
                      onChange={this.onImageChange} 
                      className="filetype"                                                        
                      id="group_image"/>   
                      <img id="target" alt=''  height="100px"                      
                      width="100px" src={this.state.PhotoFileName}                     
                  /> 
              </div>       
              <div className="form-group">
                  <span className="mr-2">
                    <input type="button"  onClick={this.handleSubmit} value="Save" className="btn btn-primary" />
                  </span>
                  <span  className="mr-2">
                  <button  className="btn btn-primary" onClick={this.handleCancell}>Cancel</button>          
                  </span>
              </div>               
          </form>    
        </Modal>   
        </main>
      </React.Fragment>
    )
  }
}
export default ListMerchandise;
