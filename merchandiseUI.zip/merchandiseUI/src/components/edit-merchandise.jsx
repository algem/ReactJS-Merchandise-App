/* eslint-disable no-undef */
import React, { Component } from 'react'
//import { connect } from 'react-redux'
const PhotoUrl = "http://localhost:50976/Photos/";
class EditMerchandise extends Component {
    constructor() {
        super();
        this.state = {
          counter: null,
        };
      }

    render() {   
        alert('ok');
        const PhotoFile = PhotoUrl +  this.props.counter.PhotoFileName ;     
        return (  
            <div>  
               
               <img src={PhotoFile} height="100" width="100" alt=""></img>       
                <span>{this.props.counter.Name} </span>  
               
                 <span>{this.currencyFormat(this.props.counter.UnitPrice)}/</span>
                 <span>{this.props.counter.UnitMeasurement}</span>  
            </div>       
        );
    }
    
    currencyFormat(num) {
        if (num === null) {
           num = 0.00; 
        }
        return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
     }

    

    formatCount(){
        if (this.props.counter === null) {
            this.props.counter = 0;
        }
        const {order} = this.props.counter;
        return order === 0 ? "Zero" : order;
    }
}

export default EditMerchandise
