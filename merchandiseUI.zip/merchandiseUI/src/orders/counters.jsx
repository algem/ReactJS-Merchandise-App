import React, { Component } from 'react';
import Counter from './counter'
class Counters extends Component {
   
    render() { 
       const {onReset, counters, onDelete, onIncrement,
        onDecrement,onCheckout,totalAmt} = this.props
        return (
            <div>
                <button 
                    onClick={onReset}                    
                    className="btn btn-primary btn-sm m-2">Reset
                </button>
                <button 
                    onClick={onCheckout}
                    className="btn btn-primary btn-sm m-2">Checkout
                </button>
               <span>{totalAmt}</span>             
                {counters.map(counter => (
                    <Counter 
                        onCheckout={onCheckout}
                        key={counter.id} 
                        onDelete={onDelete} 
                        onIncrement={onIncrement}
                        onDecrement={onDecrement}
                        counter={counter}
                        //totalAmt={totalAmt}
                    />                
                ))}           
            </div>
        );
    }
}
export default Counters ;