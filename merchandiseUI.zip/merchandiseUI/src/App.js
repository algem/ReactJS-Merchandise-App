/* eslint-disable react/jsx-no-target-blank */

import React, { Component } from 'react';
import {BrowserRouter as Router, Route, Link } from '../node_modules/react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css"
import ListMerchandise from './components/ListMerchandise';
import CreateMerchandise from './components/create-merchandise';
import EditMerchandise from './components/edit-merchandise';
import logo from "./image/logo.png"
import AppOrder from './orders/AppOrder'

export default class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
          <nav className="navbar navbar-expand-sm navbar-light bg-light">
            <a className="navbar-brand" href="https://www.codeproject.com/Articles/Al-Moje" target="_blank">
              <img src={logo} width="24" height="24" alt="CodingTheSmartway.com" />
            </a>         
          <Link to="/" className="navbar-brand"></Link>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav mr-auto">
              <li className="navbar-item">
                <Link to="/" className="nav-link">Items</Link>
              </li>
              <li className="navbar-item mr-4">
                <Link to="/create" className="nav-link">Create</Link>
              </li>
              <li className="navbar-item">
                <Link to="/orders" className="nav-link">Order(s)</Link>
              </li>
            </ul>
          </div>
          </nav>
          <Route path="/" exact component={ListMerchandise}/>
          <Route path="/create" component={CreateMerchandise} />
          <Route path="/edit/:id" component={EditMerchandise} />
          <Route path="/orders" component={AppOrder} />
        </div>
      </Router>
    );
  }
}

