﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Items
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public string UnitMeasurement { get; set; }
        public string Priority { get; set; }
        public string PhotoFileName { get; set; }
        public double UnitPrice { get; set; }
        public bool Completed { get; set; }
        public int order { get; set; }
    }
}