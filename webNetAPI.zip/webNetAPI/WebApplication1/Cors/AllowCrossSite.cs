﻿using System.Web.Http.Controllers;
using System.Web.Mvc;
using System.Web.Http.Filters;
using System;

namespace WebApplication1.Cors
{
    //public class AllowCrossSite : System.Web.Mvc.ActionFilterAttribute
    //{
    //    public override void OnActionExecuting(ActionExecutingContext filterContext)
    //    {
    //        filterContext.RequestContext.HttpContext.Response.Clear();
    //        filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Credentials", "true");
    //        filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
    //        filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Headers", "content-type");
    //        filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Credentials", "true");
    //        filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, DELETE");

    //        base.OnActionExecuting(filterContext);
    //    }
    //}

    //public class AllowCrossSite : System.Web.Http.Filters.ActionFilterAttribute
    //{
    //    //public override void OnActionExecuting(HttpActionContext actionContext)
    //    //{
    //    actionContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Credentials", "true");
    //    actionContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
    //    actionContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Headers", "content-type");
    //    actionContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Credentials", "true");
    //    actionContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, DELETE");

    //    base.OnActionExecuting(actionContext);
    //}


    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class AllowCrossSite : System.Web.Http.Filters.ActionFilterAttribute
    {
        private const string IncomingOriginHeader = "Origin";
        private const string OutgoingOriginHeader = "Access-Control-Allow-Origin";
        private const string OutgoingMethodsHeader = "Access-Control-Allow-Methods";
        private const string OutgoingAgeHeader = "Access-Control-Max-Age";

        
        public override void OnActionExecuting(HttpActionContext filterContext)
        {
            var isLocal = true;  // filterContext.Request.isLocal;
            var originHeader = filterContext.Request.Headers.Referrer; //.GetValues(IncomingOriginHeader);

            
            var response = filterContext.Response;

            //if (!string.IsNullOrWhiteSpace(originHeader.ToString()) && (isLocal || IsAllowedOrigin(originHeader.ToString())))
            //{
            //    response.ht.Headers(.AddHeader(OutgoingOriginHeader, originHeader);
            //    response.AddHeader(OutgoingMethodsHeader, "GET,POST,OPTIONS");
            //    response.AddHeader(OutgoingAgeHeader, "3600");
            //}
        }

        private bool IsAllowedOrigin(string originHeader)
        {
            // ** replace with your own logic to check the origin header
            return true;
        }
    }

}
