﻿using WebApplication1.Models;
using System;
using System.Web.Http;
using System.Net.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Web.Http.Cors;
using HttpContext = System.Web.HttpContext;
using System.Web.Http.Description;
using System.Text;

namespace WebApplication1.Controllers
{
    // A Customized API Methods
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ItemsController : ApiController
    {
         private SwaggerIntegrationContext db = new SwaggerIntegrationContext();

        [ResponseType(typeof(Items))]
        [Route("api/GetAllRecords")]
        [HttpGet]
        public HttpResponseMessage GetAllRecords()
        {
            string qry = @"SELECT [id],[ItemName],[UnitMeasurement],[PhotoFileName],[UnitPrice],[order]  FROM [ProductDB].[dbo].[Items]  order by id DESC";
            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(qry, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [ResponseType(typeof(Items))]
        [Route("api/GetFilterRecords")]
        [HttpGet]
        public HttpResponseMessage GetFilterRecords(string _field, string _searchText = null)
        {
            StringBuilder sb = new StringBuilder();
            if (_searchText is null)
            {
                sb.AppendLine("select *");
                sb.AppendLine(" from dbo.Items order by id DESC");
            }
            else
            {
                sb.AppendLine("select * from dbo.Items");
                sb.AppendLine(" where " + _field.ToLower() + " LIKE '%" + _searchText.ToLower() + "%'");
                sb.AppendLine( "order by id DESC");
            }

            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(sb.ToString(), conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [ResponseType(typeof(Items))]
        [Route("api/AddCustomerRecord")]
        [HttpPost]
        public string AddCustomerRecord(User user)
        {

            return "Added Successfully!";
        }


        [ResponseType(typeof(Items))]
        [Route("api/AddRecord")]
        [HttpPost]
        public string AddRecord(Items item)
        {
            try
            {
                string qry = @"insert into dbo.Items(ItemName,UnitMeasurement,UnitPrice,Priority,PhotoFileName)values(
                        '" + item.ItemName + @"'
                        ,'" + item.UnitMeasurement + @"'
                        ," + item.UnitPrice + @"
                         ,'" + item.Priority + @"' 
                         ,'" + item.PhotoFileName + @"'
                        )";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully!";
            }
            catch (Exception ex)
            {
                return "Failure to Add!";
            }
        }

        [ResponseType(typeof(Items))]
        [Route("api/UpdateRecord")]
        [HttpPut]
        public string UpdateItems(Items item)
        {
            try
            {              
                if (item.PhotoFileName.Contains("http"))
                {
                    item.PhotoFileName = item.PhotoFileName.Substring(item.PhotoFileName.LastIndexOf("/")+1);
                }
                string qry = @"
                update dbo.Items set 
                ItemName = '" + item.ItemName + @"'
                ,UnitMeasurement = '" + item.UnitMeasurement + @"'
                ,UnitPrice = '" + item.UnitPrice + @"'
                ,PhotoFileName = '" + item.PhotoFileName + @"'
                where id = " + item.Id + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfully!";
            }
            catch (Exception ex)
            {
                return "Failure to Update!";
            }
        }

        [ResponseType(typeof(Items))]
        public string Delete(int id)
        {
            try
            {
                string qry = @"delete from dbo.Items where id =" + id + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfully!";
            }
            catch (Exception ex)
            {
                return "Failure to Delete!";
            }
        }

        [ResponseType(typeof(Items))]
        [Route("api/SaveFile")]
        [HttpPost]
        public string SaveFile()
        {
            try
            {
                var httpRequest = HttpContext.Current.Request;
                var postedFile = httpRequest.Files[0];
                var filename = postedFile.FileName;
                string physicalPath = HttpContext.Current.Server.MapPath("~/Photos/" + filename);
                postedFile.SaveAs(physicalPath);
                return filename;
            }
            catch (Exception)
            {
                return "anonymous.png";
            }
        }
       
    }
}
